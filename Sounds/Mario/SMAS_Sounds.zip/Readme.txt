A huge collection of SMAS Sounds. Credit for:
- Origionals by the Trasher
- Tons more by Gameactive